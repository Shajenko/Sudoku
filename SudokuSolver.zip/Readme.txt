To run SudokuSolver:

1) Extract all files in this zip file to the same directory, e.g. C:\Program Files\SudokuSolver
2) Double-click on Sudokusolver.exe
3) Enjoy!